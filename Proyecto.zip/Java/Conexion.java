package Videojuegos;

public class Conexion {
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.SQLException;

	public class Conexion {
	    public static Connection conectar() throws SQLException {
	        String url = "jdbc:mysql://localhost:3306/inventario";
	        String user = "root";
	        String pass = "tu_contraseña";
	        return DriverManager.getConnection(url, user, pass);
	    }
	}
}
