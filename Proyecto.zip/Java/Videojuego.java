package Videojuegos;

public class Videojuego {
	private String titulo;
    private String genero;
    private String plataforma;
    private String estado;

    public Videojuego(String titulo, String genero, String plataforma, String estado) {
        this.titulo = titulo;
        this.genero = genero;
        this.plataforma = plataforma;
        this.estado = estado;
    }

    public void agregar(Connection conn, int usuarioId) throws SQLException {
        String sql = "INSERT INTO videojuegos(titulo, genero, plataforma, estado) VALUES (?, ?, ?, ?)";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, titulo);
        stmt.setString(2, genero);
        stmt.setString(3, plataforma);
        stmt.setString(4, estado);
        stmt.executeUpdate();
    }
}
