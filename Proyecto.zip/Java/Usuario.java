package Videojuegos;

public class Usuario {
	private int id;
    private String nombre;
    private String email;
    private String contraseña;
    private String preferencias;

    public Usuario(String nombre, String email, String contraseña, String preferencias) {
        this.nombre = nombre;
        this.email = email;
        this.contraseña = contraseña;
        this.preferencias = preferencias;
    }

    public void registrar(Connection conn) throws SQLException {
        String sql = "INSERT INTO usuarios(nombre, email, contraseña, preferencias) VALUES (?, ?, ?, ?)";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, nombre);
        stmt.setString(2, email);
        stmt.setString(3, contraseña);
        stmt.setString(4, preferencias);
        stmt.executeUpdate();
    }
}
