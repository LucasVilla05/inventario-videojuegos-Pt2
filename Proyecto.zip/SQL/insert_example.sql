
INSERT INTO usuarios (nombre, email, contraseña, preferencias)
VALUES ('Lucas', 'lucas@mail.com', '123456', 'Acción, Aventura');

INSERT INTO videojuegos (titulo, genero, plataforma, fecha_adquisicion, estado)
VALUES ('The Last of Us', 'Aventura', 'PlayStation', '2024-01-10', 'Finalizado');

INSERT INTO inventario (usuario_id, videojuego_id)
VALUES (1, 1);

INSERT INTO recomendaciones (usuario_id, videojuego_sugerido)
VALUES (1, 'Uncharted 4');
