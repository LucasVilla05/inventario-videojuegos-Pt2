
-- Ver todos los juegos de un usuario
SELECT v.titulo FROM videojuegos v
JOIN inventario i ON v.id = i.videojuego_id
WHERE i.usuario_id = 1;

-- Buscar juegos por plataforma
SELECT * FROM videojuegos WHERE plataforma = 'PC';

-- Detectar juegos duplicados por título
SELECT titulo, COUNT(*) AS cantidad
FROM videojuegos
GROUP BY titulo
HAVING COUNT(*) > 1;

-- Ver recomendaciones por usuario
SELECT videojuego_sugerido
FROM recomendaciones
WHERE usuario_id = 1;
